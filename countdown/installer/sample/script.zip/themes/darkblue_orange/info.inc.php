<?php
/* $Id: info.inc.php,v 1.1 2005/02/03 06:03:58 nuhpardon Exp $ */
/* Theme information */
$theme_name = 'Darkblue/orange';
$theme_version = 1;
$theme_generation = 1;
?>
